package com.online.garments.deal.bean;


public interface DropdownListBean
{
	public String getKey();

	public String getValue();
}
